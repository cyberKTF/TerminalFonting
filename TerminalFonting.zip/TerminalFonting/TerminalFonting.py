# template
capitalA = ('--00000--', '-0000000-', '00-----00', '00-----00', '000000000', '000000000', '00-----00', '00-----00', '00-----00', '00-----00')
capitalB = ('0000000--', '00----00-', '00-----00', '00----00-', '0000000--', '0000000--', '00----00-', '00-----00', '00----00-', '0000000--')
capitalC = ('----00000', '--000----', '-00------', '00-------', '00-------', '00-------', '00-------', '-00------', '--000----', '----00000')
capitalD = ('00000----', '00---00--', '00----00-', '00-----00', '00-----00', '00-----00', '00-----00', '00----00-', '00---00--', '00000----')
capitalE = ('000000000', '000000---', '000------', '000------', '0000000--', '0000000--', '000------', '000------', '000000---', '000000000')
capitalF = ('000000000', '000000---', '00-------', '00-------', '0000000--', '000000---', '00-------', '00-------', '00-------', '00-------')
capitalG = ('---0000--', '--00--00-', '-00----00', '00-------', '00-------', '00---0000', '00-----00', '-00----00', '--00--00-', '---0000--')
capitalH = ('00-----00', '00-----00', '00-----00', '00-----00', '000000000', '00-----00', '00-----00', '00-----00', '00-----00', '00-----00')
capitalI = ('---000---', '---000---', '---000---', '---000---', '---000---', '---000---', '---000---', '---000---', '---000---', '---000---')
capitalJ = ('-------00', '-------00', '-------00', '-------00', '-------00', '-------00', '-------00', '00-----00', '-00---00-', '---000---')
capitalK = ('00----000', '00---000-', '00--00---', '00-00----', '0000-----', '0000-----', '00-00----', '00--00---', '00---000-', '00----000')
capitalL = ('00-------', '00-------', '00-------', '00-------', '00-------', '00-------', '00-------', '00-------', '000000000', '000000000')
capitalM = ('00-----00', '00-----00', '000---000', '0000-0000', '00-000-00', '00--0--00', '00-----00', '00-----00', '00-----00', '00-----00')
capitalN = ('00-----00', '000----00', '0000---00', '00000--00', '000000-00', '00-000000', '00--00000', '00---0000', '00----000', '00-----00')
capitalO = ('---000---', '--00-00--', '-00---00-', '00-----00', '00-----00', '00-----00', '00-----00', '-00---00-', '--00-00--', '---000---')
capitalP = ('0000000--', '00----00-', '00-----00', '00-----00', '00----00-', '0000000--', '00-------', '00-------', '00-------', '00-------')
capitalQ = ('---000---', '--00-00--', '-00---00-', '00-----00', '00-----00', '00-----00', '00-----00', '-00---00-', '---0000--', '-----0000')
capitalR = ('0000000--', '00----00-', '00-----00', '00-----00', '00----00-', '0000000--', '00----00-', '00-----00', '00-----00', '00-----00')
capitalS = ('--00000--', '-00---00-', '00-----00', '00-----00', '--000----', '----000--', '00-----00', '00-----00', '-00---00-', '--00000--')
capitalT = ('000000000', '000000000', '---000---', '---000---', '---000---', '---000---', '---000---', '---000---', '---000---', '---000---')
capitalU = ('00-----00', '00-----00', '00-----00', '00-----00', '00-----00', '00-----00', '00-----00', '00-----00', '-00---00-', '--00000--')
capitalV = ('00-----00', '00-----00', '00-----00', '00-----00', '00-----00', '00-----00', '00-----00', '-00---00-', '--00-00--', '---000---')
capitalW = ('00-----00', '00-----00', '00-----00', '00-----00', '00--0--00', '00-000-00', '0000-0000', '000---000', '00-----00', '00-----00')
capitalX = ('00-----00', '00-----00', '00-----00', '-00---00-', '--00-00--', '---000---', '--00-00--', '-00---00-', '00-----00', '00-----00')
capitalY = ('00-----00', '00-----00', '00-----00', '-00---00-', '--00-00--', '---000---', '---000---', '---000---', '---000---', '---000---')
capitalZ = ('000000000', '-------00', '------00-', '-----00--', '----00---', '---00----', '--00-----', '-00------', '00-------', '000000000')
# mapping
characterDictionary = {
    'A': capitalA, 'B': capitalB, 'C': capitalC, 'D': capitalD, 'E': capitalE, 'F': capitalF,
    'G': capitalG, 'H': capitalH,  'I': capitalI, 'J': capitalJ, 'K': capitalK, 'L': capitalL,
    'M': capitalM, 'N': capitalN, 'O': capitalO, 'P': capitalP, 'Q': capitalQ, 'R': capitalR,
    'S': capitalS, 'T': capitalT, 'U': capitalU, 'V': capitalV, 'W': capitalW, 'X': capitalX,
    'Y': capitalY, 'Z': capitalZ, ' ': '----'
}

# asking for the location to save the TXT file
while True:
    location = input('Where Do You Wanna Store the TXT File? ')
    if location[-1] == '\\':
        print('Shouldn\'t End with \\ !', 'Try Again!', sep='\n')
    else:
        break
# input & input verification
while True:
    userInput = input('Enter Your Text (Only Letters and Space): ').upper().strip()
    for invalidChar in userInput:
        if invalidChar not in characterDictionary.keys():
            print('Invalid Character Detected!', 'Try Again', sep='\n')
            break
        else:
            continue
    break
# creating text line by line
lineNumber = 0  # indicates the line in-progress. example: line 1 or 2 of the output text
                # NOTE: lines start at 0 (zero), meaning that the 1st line of the output text is indicated as 0 (zero), 2nd line 1 (one), etc.
# output text line by line
while lineNumber != 10:
    lineValue = ''  # each line of output text is created in this variable before appending to terminalTypingOutput.txt
    characterCount = 0 # stores the
    for character in userInput: # loops through the "userInput" to determine the length and the characters in it
        if (characterCount + 1) == len(userInput):
            lineValue += f'{characterDictionary[character][lineNumber]}\n'
        elif character == ' ':
            lineValue += f'{characterDictionary[character]}'
            characterCount += 1
        else:
            lineValue += f'{characterDictionary[character][lineNumber]}--'
            characterCount += 1
    with open(rf'{location}\TTPOutput.txt', 'a') as output:
        output.write(lineValue)
    lineNumber += 1
